
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'hippostu',
  applicationName: 'hippo-notify-service',
  appUid: 'nSLD9wCg0lp7PJ1RZK',
  orgUid: '3e545757-c6d8-4ded-803e-2d0c4223ccdc',
  deploymentUid: 'ea6a945b-d356-472a-aba3-8bb367bc7bb7',
  serviceName: 'hippo-notify',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'hippo-notify-dev-sendEmail', timeout: 6 };

try {
  const userHandler = require('./sendEmail.js');
  module.exports.handler = serverlessSDK.handler(userHandler.sendTemplatedEmail, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}